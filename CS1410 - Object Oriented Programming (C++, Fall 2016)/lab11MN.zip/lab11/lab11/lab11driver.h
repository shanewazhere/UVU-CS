
// Author: Max Nelson
// Assignment: lab11
// Instructor: David Wagstaff
// Class: CS1410 001
// Date Written: 11/2/2016
// Description: driver header
// -----------
//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.

//header for driver
#pragma once
#include <string>
#include <iostream>
#include "Money.h"
using namespace std;


